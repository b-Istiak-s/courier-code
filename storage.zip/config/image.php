<?php


return [
    'driver' => 'gd', // or 'imagick' if your server supports it
];